import { useEffect, useState } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import { Menu, X, ChevronDown } from 'lucide-react';
import logo from '../assets/civiora-logo-full-lockup-transparent.png';

const NAV_LINKS = [
  { to: '/', label: 'Home' },
  { 
    to: '/about', 
    label: 'About',
    dropdown: [
      { to: '/about', label: 'About Civiora' },
      { to: '/who-we-are', label: 'Who We Work With' },
      { to: '/how-it-works', label: 'How We Work' },
      { to: '/why-civiora', label: 'Why Civiora' },
    ]
  },
  { to: '/training-development', label: 'Training & Development' },
  { to: '/blog', label: 'Blog' },
  { to: '/founder', label: 'Founder' },
  { to: '/contact', label: 'Contact' },
];

export default function Navbar({ mobileMenuOpen, setMobileMenuOpen }) {
  const [scrolled, setScrolled] = useState(false);
  const [internalOpen, setInternalOpen] = useState(false);
  const location = useLocation();

  const open = mobileMenuOpen !== undefined ? mobileMenuOpen : internalOpen;
  const setOpen = setMobileMenuOpen || setInternalOpen;

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Lock body & html scroll when mobile menu is open
  useEffect(() => {
    if (open) {
      document.body.style.overflow = 'hidden';
      document.documentElement.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
      document.documentElement.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
      document.documentElement.style.overflow = '';
    };
  }, [open]);

  // Handle escape key to close mobile menu
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape' && open) {
        setOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [open, setOpen]);

  // Close mobile drawer on route change
  useEffect(() => {
    setOpen(false);
  }, [location.pathname, setOpen]);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 bg-white/95 backdrop-blur-md border-b border-navy-100/70 shadow-[0_2px_12px_rgba(11,42,84,0.04)] ${
        scrolled ? 'py-2' : 'py-2.5 md:py-3'
      }`}
    >
      <nav 
        aria-label="Main Navigation" 
        className="max-w-content mx-auto px-4 sm:px-6 md:px-10 flex items-center justify-between"
      >
        <Link 
          to="/" 
          className="flex items-center gap-2 group focus:outline-none focus-visible:ring-2 focus-visible:ring-gold-500 rounded-lg shrink-0" 
          onClick={() => setOpen(false)}
          aria-label="Civiora Home"
        >
          <img 
            src={logo} 
            alt="CIVIORA" 
            className="h-9 sm:h-10 md:h-12 w-auto object-contain transition-transform duration-300 group-hover:scale-105" 
          />
        </Link>

        {/* Desktop Navigation Links */}
        <ul className="hidden xl:flex items-center gap-3.5 2xl:gap-5 font-body text-xs 2xl:text-sm tracking-wide text-navy-800 whitespace-nowrap">
          {NAV_LINKS.map((l) => (
            <li key={l.to} className={l.dropdown ? 'relative group' : ''}>
              {l.dropdown ? (
                <>
                  <NavLink
                    to={l.to}
                    className={({ isActive }) =>
                      `relative py-1 transition-colors duration-200 hover:text-gold-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-gold-500 rounded flex items-center gap-1 after:content-[''] after:absolute after:left-0 after:-bottom-0.5 after:h-[2px] after:bg-gold-500 after:transition-all after:duration-200 ${
                        isActive || location.pathname === '/about' || location.pathname === '/who-we-are' || location.pathname === '/how-it-works' || location.pathname === '/why-civiora' || location.pathname === '/pathways'
                          ? 'text-gold-700 font-semibold after:w-full'
                          : 'after:w-0 hover:after:w-full'
                      }`
                    }
                  >
                    <span>{l.label}</span>
                    <ChevronDown size={13} className="text-navy-500 group-hover:rotate-180 transition-transform duration-200" />
                  </NavLink>

                  {/* Dropdown Menu (Exact 2 boxes as drawn in user reference screenshot) */}
                  <div className="absolute left-0 top-full pt-2 opacity-0 translate-y-1 invisible group-hover:opacity-100 group-hover:translate-y-0 group-hover:visible transition-all duration-200 z-50 pointer-events-none group-hover:pointer-events-auto">
                    <div className="w-56 bg-white rounded-2xl shadow-xl border border-navy-100 p-2 space-y-1">
                      {l.dropdown.map((sub) => (
                        <NavLink
                          key={sub.to}
                          to={sub.to}
                          className={({ isActive }) =>
                            `flex items-center px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-medium transition-all ${
                              isActive
                                ? 'bg-gold-50 text-gold-900 font-bold border-l-4 border-gold-500'
                                : 'text-navy-800 hover:bg-navy-50 hover:text-navy-950'
                            }`
                          }
                        >
                          <span>{sub.label}</span>
                        </NavLink>
                      ))}
                    </div>
                  </div>
                </>
              ) : (
                <NavLink
                  to={l.to}
                  end={l.to === '/'}
                  className={({ isActive }) =>
                    `relative py-1 transition-colors duration-200 hover:text-gold-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-gold-500 rounded after:content-[''] after:absolute after:left-0 after:-bottom-0.5 after:h-[2px] after:bg-gold-500 after:transition-all after:duration-200 ${
                      isActive
                        ? 'text-gold-700 font-semibold after:w-full'
                        : 'after:w-0 hover:after:w-full'
                    }`
                  }
                >
                  {l.label}
                </NavLink>
              )}
            </li>
          ))}
        </ul>

        {/* Desktop Primary CTA */}
        <Link
          to="/contact"
          className="hidden xl:inline-flex items-center justify-center px-5 py-2.5 rounded-full bg-navy-800 hover:bg-navy-900 text-white text-xs font-semibold uppercase tracking-wider transition-all duration-200 shadow-sm hover:shadow hover:shadow-navy-950/20 focus:outline-none focus:ring-2 focus:ring-navy-700 focus:ring-offset-2 shrink-0"
        >
          Connect with Us
        </Link>

        {/* Mobile Hamburger / Close Button */}
        <button
          type="button"
          className="xl:hidden text-navy-800 p-2.5 min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl hover:bg-navy-50 focus:outline-none focus:ring-2 focus:ring-gold-400 active:scale-95 transition-all"
          aria-label={open ? 'Close navigation menu' : 'Open navigation menu'}
          aria-expanded={open}
          aria-controls="mobile-navigation"
          onClick={() => setOpen(!open)}
        >
          {open ? <X size={26} aria-hidden="true" /> : <Menu size={26} aria-hidden="true" />}
        </button>
      </nav>

      {/* Backdrop overlay for mobile (behind drawer at z-10) */}
      {open && (
        <div
          className="fixed inset-0 bg-navy-950/60 backdrop-blur-sm z-10 xl:hidden"
          onClick={() => setOpen(false)}
          aria-hidden="true"
        />
      )}

      {/* Mobile Drawer (in front of backdrop at z-20) */}
      <div
        id="mobile-navigation"
        aria-hidden={!open}
        className={`xl:hidden relative z-20 w-full max-w-full overflow-x-hidden transition-all duration-300 ease-in-out bg-white shadow-2xl ${
          open ? 'max-h-[calc(100dvh-64px)] sm:max-h-[calc(100vh-64px)] overflow-y-auto border-t border-navy-100' : 'max-h-0 overflow-hidden'
        }`}
      >
        <ul className="flex flex-col px-4 sm:px-6 pt-4 pb-12 gap-1.5 font-body text-navy-800">
          {NAV_LINKS.map((l) => (
            <li key={l.to} className="space-y-1">
              {l.dropdown ? (
                <>
                  <div className="flex items-center justify-between px-3.5 py-2 text-xs uppercase tracking-wider font-bold text-navy-400">
                    <span>{l.label}</span>
                  </div>
                  <div className="pl-2 space-y-1 border-l-2 border-navy-100 ml-3">
                    {l.dropdown.map((sub) => (
                      <NavLink
                        key={sub.to}
                        to={sub.to}
                        onClick={() => setOpen(false)}
                        className={({ isActive }) =>
                          `flex items-center min-h-[44px] px-3.5 rounded-xl text-sm font-medium tracking-wide transition-colors ${
                            isActive 
                              ? 'bg-gold-50 text-gold-800 font-semibold border-l-4 border-gold-500' 
                              : 'hover:bg-navy-50 text-navy-800 active:bg-navy-100'
                          }`
                        }
                      >
                        {sub.label}
                      </NavLink>
                    ))}
                  </div>
                </>
              ) : (
                <NavLink
                  to={l.to}
                  end={l.to === '/'}
                  onClick={() => setOpen(false)}
                  className={({ isActive }) =>
                    `flex items-center min-h-[48px] px-3.5 rounded-xl text-sm font-medium tracking-wide transition-colors ${
                      isActive 
                        ? 'bg-gold-50 text-gold-800 font-semibold border-l-4 border-gold-500' 
                        : 'hover:bg-navy-50 text-navy-800 active:bg-navy-100'
                    }`
                  }
                >
                  {l.label}
                </NavLink>
              )}
            </li>
          ))}
          <li className="pt-3">
            <Link
              to="/contact"
              onClick={() => setOpen(false)}
              className="flex items-center justify-center min-h-[48px] w-full text-center bg-gold-500 hover:bg-gold-400 text-navy-950 text-sm font-semibold tracking-wide px-5 py-3 rounded-full transition-all duration-200 shadow-sm active:scale-98"
            >
              Connect with Us
            </Link>
          </li>
        </ul>
      </div>
    </header>
  );
}
