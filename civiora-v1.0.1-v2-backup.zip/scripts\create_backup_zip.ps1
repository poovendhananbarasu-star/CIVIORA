Add-Type -AssemblyName System.IO.Compression.FileSystem

$sourceDir = "C:\Users\TECHVITY\Documents\GitHub\CIVIORA\civiora-website-clean (1)\civiora-clean-website"
$zipPath = "C:\Users\TECHVITY\Documents\GitHub\CIVIORA\civiora-v1.0.1-v2-backup.zip"

if (Test-Path $zipPath) {
    Remove-Item $zipPath -Force
}

$tempStaging = Join-Path $env:TEMP ("civiora_backup_" + [System.Guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $tempStaging | Out-Null

try {
    Write-Host "Copying project source to temporary staging directory (excluding node_modules and dist)..."
    
    # Use robocopy to copy while excluding node_modules, dist, and .git
    $robocopyArgs = @(
        $sourceDir,
        $tempStaging,
        "/E",
        "/XD", "node_modules", "dist", ".git", ".firebase",
        "/XF", "firebase-debug.log",
        "/R:1",
        "/W:1",
        "/NFL", "/NDL", "/NJH", "/NJS"
    )
    & robocopy @robocopyArgs
    
    Write-Host "Creating zip archive: $zipPath..."
    [System.IO.Compression.ZipFile]::CreateFromDirectory($tempStaging, $zipPath, [System.IO.Compression.CompressionLevel]::Optimal, $false)
    
    $zipItem = Get-Item $zipPath
    Write-Host "Backup zip created successfully: $($zipItem.FullName) ($([math]::Round($zipItem.Length / 1MB, 2)) MB)"
}
finally {
    if (Test-Path $tempStaging) {
        Remove-Item -Path $tempStaging -Recurse -Force -ErrorAction SilentlyContinue
    }
}
