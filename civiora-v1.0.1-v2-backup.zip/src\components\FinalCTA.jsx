import { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { 
  Mail, 
  Phone, 
  MapPin, 
  CheckCircle2, 
  Send, 
  AlertCircle,
  Loader2,
  Building2,
  Users2,
  ExternalLink
} from 'lucide-react';
import Reveal from './Reveal';
import SpotlightCard from './effects/SpotlightCard';
import { submitAppointmentRequest, isFirebaseConfigured } from '../firebase';
import { trackMetaLead } from '../utils/metaPixel';

const INSTITUTION_TYPES = [
  'School',
  'College',
  'University',
  'Academic/Specialist Partner',
  'Other Institution',
];

const DISCUSSION_FORMATS = [
  'In-person discussion (Bengaluru)',
  'Video conference',
  'Telephone discussion',
];

// A basic client-side deterrent only. Firebase App Check and a server-side
// endpoint remain the required controls for production abuse protection.
const SUBMISSION_COOLDOWN_MS = 30_000;

const WHO_CAN_CONNECT = [
  'School principals and school leadership teams',
  'College principals and management councils',
  'University deans, registrars and department chairs',
  'Institutional career development & placement leaders',
  'Specialist educators and prospective academic partners',
];

export default function FinalCTA() {
  const [searchParams] = useSearchParams();
  const requestedType = searchParams.get('type');

  const [formData, setFormData] = useState({
    institutionType: INSTITUTION_TYPES[0],
    representativeName: '',
    designation: '',
    institutionName: '',
    location: '',
    officialEmail: '',
    telephone: '',
    requirement: '',
    discussionFormat: DISCUSSION_FORMATS[0],
    consent: false,
    website: '',
  });

  const [lastSubmissionAt, setLastSubmissionAt] = useState(0);

  useEffect(() => {
    if (requestedType && INSTITUTION_TYPES.includes(requestedType)) {
      setFormData((prev) => ({ ...prev, institutionType: requestedType }));
    }
  }, [requestedType]);

  const [status, setStatus] = useState({
    submitting: false,
    submitted: false,
    error: null,
    documentId: null,
  });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Honeypot: legitimate users never see this field. Do not persist bot data.
    if (formData.website.trim()) {
      setStatus({ submitting: false, submitted: true, error: null, documentId: null });
      return;
    }

    if (Date.now() - lastSubmissionAt < SUBMISSION_COOLDOWN_MS) {
      setStatus({
        submitting: false,
        submitted: false,
        error: 'Please wait a moment before submitting another request.',
        documentId: null,
      });
      return;
    }

    if (!formData.consent) {
      setStatus({
        submitting: false,
        submitted: false,
        error: 'Please accept the consent checkbox to submit your institutional discussion request.',
        documentId: null,
      });
      return;
    }

    setStatus({ submitting: true, submitted: false, error: null, documentId: null });

    try {
      if (!isFirebaseConfigured) {
        throw new Error(
          'Database service is currently unconfigured. Please ensure environment variables are configured in .env.'
        );
      }

      // Write strictly to Firestore collection "appointmentRequests"
      const result = await submitAppointmentRequest(formData);

      // Track Meta Lead event strictly AFTER successful Firestore write confirmation, with zero form data/PII
      trackMetaLead();
      setLastSubmissionAt(Date.now());

      setStatus({
        submitting: false,
        submitted: true,
        error: null,
        documentId: result?.id || null,
      });
    } catch (err) {
      if (import.meta.env.DEV) {
        console.error('Firestore submission error:', err);
      }

      let errorMessage = 'Unable to submit your request at this time. Please try again or contact us directly at connect@civiora.co.in.';
      if (err?.code === 'permission-denied') {
        errorMessage = 'Submission was rejected due to permission constraints. Please verify all required fields and try again.';
      } else if (err?.code === 'unavailable') {
        errorMessage = 'Database service is temporarily unavailable. Please check your network connection and try again.';
      }

      setStatus({
        submitting: false,
        submitted: false,
        error: errorMessage,
        documentId: null,
      });
    }
  };

  return (
    <section id="contact-form" className="relative bg-white py-16 md:py-24 font-body">
      <div className="max-w-content mx-auto px-4 sm:px-6 md:px-10">
        
        <div className="grid lg:grid-cols-12 gap-8 md:gap-10 items-start">
          
          {/* Left Column: Who can connect & Contact Details */}
          <div className="lg:col-span-5 space-y-6 md:space-y-8">
            {/* Who can connect */}
            <Reveal className="bg-mist rounded-2xl p-4 sm:p-7 border border-navy-100 shadow-[0_2px_8px_rgba(11,42,84,0.03)]">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-navy-900 text-gold-400 flex items-center justify-center shrink-0">
                  <Users2 size={20} />
                </div>
                <h3 className="font-display text-lg sm:text-xl text-navy-900 font-semibold leading-snug">
                  Who can connect?
                </h3>
              </div>
              <p className="text-xs sm:text-sm text-navy-600 mt-3 leading-relaxed">
                Civiora works directly with institutional leadership and verified academic partners:
              </p>
              <ul className="mt-4 space-y-2.5">
                {WHO_CAN_CONNECT.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-navy-700">
                    <CheckCircle2 size={16} className="text-gold-500 shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </Reveal>

            {/* Official Contact Details */}
            <Reveal delay={100}>
              <SpotlightCard 
                className="bg-navy-900 text-white rounded-2xl p-4 sm:p-8 border border-white/10 shadow-xl"
                spotlightColor="rgba(0, 242, 254, 0.2)"
              >
                <h3 className="font-display text-lg sm:text-xl text-gold-400 font-semibold">
                  Contact Details
                </h3>
                <p className="text-xs uppercase tracking-wider text-navy-300 mt-1 font-medium">
                  Civiora Education &amp; Institutional Services
                </p>

                <div className="mt-6 space-y-4 text-xs sm:text-sm text-navy-100">
                  <div className="flex items-start gap-3">
                    <MapPin size={17} className="text-gold-400 shrink-0 mt-0.5" />
                    <div>
                      <p className="leading-relaxed">
                        No. 134, 57, 13th Cross, Baldwins Road, Koramangala,<br />
                        Bengaluru, Karnataka – 560030
                      </p>
                      <a
                        href="https://maps.app.goo.gl/5GgFoYLVEgXDRABy7"
                        target="_blank"
                        rel="noopener noreferrer"
                        aria-label="View Civiora location on Google Maps"
                        className="inline-flex items-center gap-1.5 text-xs text-gold-400 hover:text-gold-300 underline font-medium mt-1 focus:outline-none focus:underline"
                      >
                        <span>View on Google Maps</span>
                        <ExternalLink size={12} />
                      </a>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <Phone size={17} className="text-gold-400 shrink-0" />
                    <a href="tel:+918150003610" className="hover:text-gold-300 transition-colors focus:outline-none focus:underline">
                      +91 8150003610
                    </a>
                  </div>

                  <div className="flex items-center gap-3">
                    <Mail size={17} className="text-gold-400 shrink-0" />
                    <a href="mailto:connect@civiora.co.in" className="hover:text-gold-300 transition-colors focus:outline-none focus:underline">
                      connect@civiora.co.in
                    </a>
                  </div>
                </div>

                <div className="mt-6 pt-5 border-t border-white/10 text-xs text-navy-300">
                  <p>Office hours: Monday to Friday, 9:30 AM – 6:00 PM IST</p>
                </div>
              </SpotlightCard>
            </Reveal>
          </div>

          {/* Right Column: Institutional Request Form */}
          <div className="lg:col-span-7">
            <Reveal delay={150}>
              <div className="bg-white rounded-2xl p-4 sm:p-8 md:p-10 border border-navy-100 shadow-xl shadow-navy-950/5">
                <div className="border-b border-navy-100 pb-5 mb-6">
                  <h3 className="font-display text-xl sm:text-2xl text-navy-900 font-semibold">
                    Request an Institutional Discussion
                  </h3>
                  <p className="text-xs sm:text-sm text-navy-600 mt-1">
                    Fill out the form below. We will coordinate a discussion aligned with your academic calendar.
                  </p>
                </div>

                {status.submitted ? (
                  <div className="p-6 sm:p-8 text-center bg-mist rounded-xl border border-navy-200">
                    <CheckCircle2 size={44} className="text-gold-600 mx-auto mb-3" />
                    <h4 className="font-display text-xl sm:text-2xl text-navy-900 font-semibold">
                      Discussion Request Received
                    </h4>
                    <p className="mt-3 text-sm text-navy-700 leading-relaxed max-w-md mx-auto">
                      Thank you for connecting with Civiora. Your institutional discussion request has been recorded successfully. Our team will review your priorities and get back to you shortly.
                    </p>
                    {status.documentId && (
                      <div className="mt-4 inline-flex items-center gap-2 bg-white border border-navy-200/80 px-3.5 py-2 rounded-lg text-xs text-navy-800">
                        <span className="text-navy-500 font-medium">Reference ID:</span>
                        <code className="font-mono font-semibold text-navy-900 select-all">{status.documentId}</code>
                      </div>
                    )}
                    <div className="mt-6">
                      <button
                        type="button"
                        onClick={() => {
                          setFormData({
                            institutionType: INSTITUTION_TYPES[0],
                            representativeName: '',
                            designation: '',
                            institutionName: '',
                            location: '',
                            officialEmail: '',
                            telephone: '',
                            requirement: '',
                            discussionFormat: DISCUSSION_FORMATS[0],
                            consent: false,
                            website: '',
                          });
                          setStatus({ submitting: false, submitted: false, error: null, documentId: null });
                        }}
                        className="px-6 py-2.5 rounded-xl text-xs font-semibold bg-navy-900 text-white hover:bg-navy-800 transition-colors"
                      >
                        Submit Another Request
                      </button>
                    </div>
                  </div>
                ) : (
                  <form method="post" onSubmit={handleSubmit} className="space-y-5">
                    {status.error && (
                      <div className="p-4 rounded-xl bg-red-50 border border-red-200 flex items-start gap-3 text-red-800 text-xs sm:text-sm">
                        <AlertCircle size={17} className="shrink-0 mt-0.5 text-red-600" />
                        <span>{status.error}</span>
                      </div>
                    )}

                    {/* Institution Type */}
                    <div>
                      <label htmlFor="institutionType" className="block text-xs font-semibold text-navy-800 uppercase tracking-wider mb-1.5">
                        Institution Type <span className="text-red-500">*</span>
                      </label>
                      <select
                        id="institutionType"
                        name="institutionType"
                        value={formData.institutionType}
                        onChange={handleChange}
                        className="w-full min-h-[44px] px-3.5 sm:px-4 py-2.5 rounded-xl border border-navy-200 bg-white text-navy-900 text-base sm:text-sm focus:outline-none focus:ring-2 focus:ring-navy-800"
                        required
                      >
                        {INSTITUTION_TYPES.map((type) => (
                          <option key={type} value={type}>
                            {type}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Representative Name & Designation */}
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="representativeName" className="block text-xs font-semibold text-navy-800 uppercase tracking-wider mb-1.5">
                          Representative Name <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          id="representativeName"
                          name="representativeName"
                          autoComplete="name"
                          value={formData.representativeName}
                          onChange={handleChange}
                          placeholder="e.g. Dr. Rajesh Sharma"
                          maxLength={150}
                          className="w-full min-h-[44px] px-3.5 sm:px-4 py-2.5 rounded-xl border border-navy-200 text-navy-900 text-base sm:text-sm focus:outline-none focus:ring-2 focus:ring-navy-800"
                          required
                        />
                      </div>
                      <div>
                        <label htmlFor="designation" className="block text-xs font-semibold text-navy-800 uppercase tracking-wider mb-1.5">
                          Designation <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          id="designation"
                          name="designation"
                          autoComplete="organization-title"
                          value={formData.designation}
                          onChange={handleChange}
                          placeholder="e.g. Principal / Dean / Director"
                          maxLength={150}
                          className="w-full min-h-[44px] px-3.5 sm:px-4 py-2.5 rounded-xl border border-navy-200 text-navy-900 text-base sm:text-sm focus:outline-none focus:ring-2 focus:ring-navy-800"
                          required
                        />
                      </div>
                    </div>

                    {/* Institution Name & Location */}
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="institutionName" className="block text-xs font-semibold text-navy-800 uppercase tracking-wider mb-1.5">
                          Institution Name <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          id="institutionName"
                          name="institutionName"
                          autoComplete="organization"
                          value={formData.institutionName}
                          onChange={handleChange}
                          placeholder="e.g. National College of Excellence"
                          maxLength={200}
                          className="w-full min-h-[44px] px-3.5 sm:px-4 py-2.5 rounded-xl border border-navy-200 text-navy-900 text-base sm:text-sm focus:outline-none focus:ring-2 focus:ring-navy-800"
                          required
                        />
                      </div>
                      <div>
                        <label htmlFor="location" className="block text-xs font-semibold text-navy-800 uppercase tracking-wider mb-1.5">
                          Location (City / State) <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          id="location"
                          name="location"
                          autoComplete="address-level2"
                          value={formData.location}
                          onChange={handleChange}
                          placeholder="e.g. Bengaluru, Karnataka"
                          maxLength={150}
                          className="w-full min-h-[44px] px-3.5 sm:px-4 py-2.5 rounded-xl border border-navy-200 text-navy-900 text-base sm:text-sm focus:outline-none focus:ring-2 focus:ring-navy-800"
                          required
                        />
                      </div>
                    </div>

                    {/* Official Email & Telephone */}
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="officialEmail" className="block text-xs font-semibold text-navy-800 uppercase tracking-wider mb-1.5">
                          Official Email <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="email"
                          id="officialEmail"
                          name="officialEmail"
                          autoComplete="email"
                          value={formData.officialEmail}
                          onChange={handleChange}
                          placeholder="name@institution.edu.in"
                          maxLength={150}
                          className="w-full min-h-[44px] px-3.5 sm:px-4 py-2.5 rounded-xl border border-navy-200 text-navy-900 text-base sm:text-sm focus:outline-none focus:ring-2 focus:ring-navy-800"
                          required
                        />
                      </div>
                      <div>
                        <label htmlFor="telephone" className="block text-xs font-semibold text-navy-800 uppercase tracking-wider mb-1.5">
                          Telephone / Mobile <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="tel"
                          id="telephone"
                          name="telephone"
                          autoComplete="tel"
                          value={formData.telephone}
                          onChange={handleChange}
                          placeholder="+91 98765 43210"
                          maxLength={50}
                          className="w-full min-h-[44px] px-3.5 sm:px-4 py-2.5 rounded-xl border border-navy-200 text-navy-900 text-base sm:text-sm focus:outline-none focus:ring-2 focus:ring-navy-800"
                          required
                        />
                      </div>
                    </div>

                    {/* Preferred Discussion Format */}
                    <div>
                      <label htmlFor="discussionFormat" className="block text-xs font-semibold text-navy-800 uppercase tracking-wider mb-1.5">
                        Preferred Discussion Format
                      </label>
                      <select
                        id="discussionFormat"
                        name="discussionFormat"
                        value={formData.discussionFormat}
                        onChange={handleChange}
                        className="w-full min-h-[44px] px-3.5 sm:px-4 py-2.5 rounded-xl border border-navy-200 bg-white text-navy-900 text-base sm:text-sm focus:outline-none focus:ring-2 focus:ring-navy-800"
                      >
                        {DISCUSSION_FORMATS.map((fmt) => (
                          <option key={fmt} value={fmt}>
                            {fmt}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Requirement Summary */}
                    <div>
                      <label htmlFor="requirement" className="block text-xs font-semibold text-navy-800 uppercase tracking-wider mb-1.5">
                        Requirement &amp; Student Context <span className="text-red-500">*</span>
                      </label>
                      <textarea
                        id="requirement"
                        name="requirement"
                        rows={4}
                        maxLength={2000}
                        value={formData.requirement}
                        onChange={handleChange}
                        placeholder="Please briefly describe your student community, development priorities, and preferred timeline..."
                        className="w-full px-3.5 sm:px-4 py-2.5 rounded-xl border border-navy-200 text-navy-900 text-base sm:text-sm focus:outline-none focus:ring-2 focus:ring-navy-800"
                        required
                      />
                    </div>

                    {/* Honeypot field. Kept off-screen and out of keyboard navigation. */}
                    <div className="absolute -left-[10000px] top-auto h-px w-px overflow-hidden" aria-hidden="true">
                      <label htmlFor="website">Website</label>
                      <input
                        id="website"
                        name="website"
                        type="text"
                        tabIndex={-1}
                        autoComplete="off"
                        value={formData.website}
                        onChange={handleChange}
                      />
                    </div>

                    {/* Contact Consent Checkbox */}
                    <div className="pt-2">
                      <label className="flex items-start gap-3 cursor-pointer text-xs sm:text-sm text-navy-700 select-none py-1">
                        <input
                          type="checkbox"
                          name="consent"
                          checked={formData.consent}
                          onChange={handleChange}
                          className="w-4 h-4 sm:w-5 sm:h-5 mt-0.5 rounded border-navy-300 text-navy-900 focus:ring-navy-800 shrink-0 cursor-pointer"
                          required
                        />
                        <span>
                          I confirm this enquiry on behalf of my institution and agree to Civiora handling this information in accordance with its{' '}
                          <Link to="/privacy-policy" target="_blank" rel="noopener noreferrer" className="text-gold-700 underline font-semibold hover:text-gold-800">
                            Privacy Policy
                          </Link>.
                        </span>
                      </label>
                    </div>

                    {/* Submit Button */}
                    <div className="pt-4">
                      <button
                        type="submit"
                        disabled={status.submitting}
                        className="btn-primary w-full justify-center text-sm sm:text-base py-3.5 min-h-[48px] disabled:opacity-60"
                      >
                        {status.submitting ? (
                          <>
                            <Loader2 size={16} className="animate-spin" />
                            <span>Processing Request...</span>
                          </>
                        ) : (
                          <>
                            <Send size={16} />
                            <span>Request an Institutional Discussion</span>
                          </>
                        )}
                      </button>
                    </div>

                  </form>
                )}
              </div>
            </Reveal>
          </div>

        </div>

      </div>
    </section>
  );
}
