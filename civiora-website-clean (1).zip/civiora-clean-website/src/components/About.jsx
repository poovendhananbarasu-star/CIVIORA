import Reveal from './Reveal';

const PROBLEMS = [
  'Generic proposals',
  'Provider coordination and accountability gaps',
  'Aspirations and readiness not mapped',
  'One-time interventions without continuity or measurement',
];

export default function About() {
  return (
    <section id="about" className="relative bg-white py-24 md:py-32">
      <div className="max-w-content mx-auto px-6 md:px-10">
        <div className="grid md:grid-cols-2 gap-14 md:gap-20 items-start">
          <Reveal>
            <p className="eyebrow">Education needs more than isolated solutions.</p>
            <h2 className="section-heading mt-4">
              &ldquo;Education needs more than isolated solutions.&rdquo;
            </h2>
            <div className="gold-rule mt-8" />
            <p className="mt-8 text-navy-700 text-lg leading-relaxed max-w-md">
              Civiora is not another coaching centre, open marketplace or one-time
              seminar company; it is an institutional solutions and coordination
              platform built around fit, quality and accountability.
            </p>
            <p className="mt-5 text-navy-700 text-lg leading-relaxed max-w-md">
              Civiora helps schools, colleges and universities identify student
              needs, design the right response, connect credible expertise and
              manage implementation through one accountable partnership.
            </p>
          </Reveal>

          <Reveal delay={150}>
            <div className="bg-mist rounded-2xl p-8 md:p-10 border border-navy-100">
              
              <ul className="mt-6 space-y-5">
                {PROBLEMS.map((p, i) => (
                  <li key={p} className="flex items-start gap-4 pb-5 border-b border-navy-100 last:border-none last:pb-0">
                    <span className="font-display text-gold-500 text-2xl leading-none mt-0.5">
                      {String(i + 1).padStart(2, '0')}
                    </span>
                    <span className="text-navy-800 leading-snug pt-0.5">{p}</span>
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>
        </div>

        <Reveal delay={200}>
          <div className="mt-20 md:mt-28 text-center">
            <p className="eyebrow">The Missing Layer</p>
            <p className="mt-5 font-display text-3xl md:text-5xl text-navy-800 leading-snug max-w-3xl mx-auto">
              Civiora is a strategic bridge.
            </p>
            <p className="mt-3 font-display italic text-2xl md:text-3xl text-gold-600">
              That bridge is Civiora.
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
