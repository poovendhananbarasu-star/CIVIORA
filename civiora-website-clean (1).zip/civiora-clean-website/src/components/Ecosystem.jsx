import Reveal from './Reveal';

const VALUE = [
  { title: 'Institutions', desc: 'Institutions get one strategic accountable interface.' },
  { title: 'Providers', desc: 'Providers get qualified opportunities.' },
  { title: 'Civiora', desc: 'Civiora earns engagement/implementation/service margin.' },
];

export default function Ecosystem() {
  return (
    <section id="ecosystem" className="relative bg-navy-900 py-24 md:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(201,150,42,0.06),_transparent_60%)]" />

      <div className="relative max-w-content mx-auto px-6 md:px-10">
        <Reveal className="text-center max-w-2xl mx-auto">
          <p className="eyebrow">The Civiora Ecosystem</p>
          <h2 className="mt-4 font-display text-3xl md:text-5xl text-white leading-tight">
            
          </h2>
          <p className="mt-6 text-navy-200 leading-relaxed">
            Institutions get one strategic accountable interface. Providers get
            qualified opportunities. Civiora earns engagement, implementation
            and service margin — an ecosystem where every side is aligned.
          </p>
        </Reveal>

        <Reveal delay={150} className="mt-16 grid sm:grid-cols-3 gap-6">
          {VALUE.map((v) => (
            <div
              key={v.title}
              className="rounded-2xl border border-white/10 bg-white/[0.03] p-7 hover:border-gold-500/40 transition-colors duration-300"
            >
              <p className="font-display text-lg text-gold-400">{v.title}</p>
              <p className="mt-3 text-navy-100 text-sm leading-relaxed">{v.desc}</p>
            </div>
          ))}
        </Reveal>
      </div>
    </section>
  );
}
