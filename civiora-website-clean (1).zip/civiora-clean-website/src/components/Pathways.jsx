import { GraduationCap, Landmark, Check } from 'lucide-react';
import Reveal from './Reveal';

const SCHOOL_POINTS = [
  'Conceptual understanding',
  'Reasoning',
  'Problem solving',
  'Communication',
  'Leadership',
  'Ethical awareness',
  'Future orientation',
];

const COLLEGE_POINTS = [
  'Student aspirations',
  'Competitive-career opportunities',
  'Civil Services',
  'State PSC',
  'SSC',
  'Banking',
  'Defence',
  'Other government careers',
];

export default function Pathways() {
  return (
    <section id="pathways" className="relative bg-mist py-24 md:py-32">
      <div className="max-w-content mx-auto px-6 md:px-10">
        <Reveal className="text-center max-w-2xl mx-auto">
          <p className="eyebrow">Institutional Pathways</p>
          <h2 className="section-heading mt-4"></h2>
        </Reveal>

        <div className="mt-16 grid lg:grid-cols-2 gap-8">
          {/* Schools */}
          <Reveal className="bg-white rounded-3xl border border-navy-100 p-9 md:p-11 hover:shadow-2xl hover:shadow-navy-900/5 transition-shadow duration-500">
            <div className="w-14 h-14 rounded-2xl bg-navy-700 flex items-center justify-center">
              <GraduationCap size={26} className="text-gold-400" />
            </div>
            <h3 className="mt-7 font-display text-2xl md:text-3xl text-navy-800">Schools</h3>
            <p className="mt-2 text-gold-600 font-medium tracking-wide text-sm uppercase">
              Build capabilities behind every future
            </p>

            <ul className="mt-7 grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3">
              {SCHOOL_POINTS.map((p) => (
                <li key={p} className="flex items-center gap-2.5 text-navy-700">
                  <Check size={16} className="text-gold-500 shrink-0" />
                  <span>{p}</span>
                </li>
              ))}
            </ul>

            <div className="mt-8 pt-6 border-t border-navy-100 space-y-2 text-sm text-navy-500">
              <p>Complements academics.</p>
              <p>Can be piloted, run at selected-grade level, or across multiple campuses.</p>
            </div>
          </Reveal>

          {/* Colleges & Universities */}
          <Reveal delay={150} className="bg-navy-800 rounded-3xl p-9 md:p-11 hover:shadow-2xl hover:shadow-navy-900/20 transition-shadow duration-500">
            <div className="w-14 h-14 rounded-2xl bg-gold-500 flex items-center justify-center">
              <Landmark size={26} className="text-navy-900" />
            </div>
            <h3 className="mt-7 font-display text-2xl md:text-3xl text-white">Colleges &amp; Universities</h3>
            <p className="mt-2 text-gold-400 font-medium tracking-wide text-sm uppercase">
              Build pathways beyond placements
            </p>

            <ul className="mt-7 grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3">
              {COLLEGE_POINTS.map((p) => (
                <li key={p} className="flex items-center gap-2.5 text-navy-100">
                  <Check size={16} className="text-gold-400 shrink-0" />
                  <span>{p}</span>
                </li>
              ))}
            </ul>

            <div className="mt-8 pt-6 border-t border-white/10 space-y-2 text-sm text-navy-200">
              <p>Demand and readiness discovery.</p>
              <p>Right pathway and specialist support, with continuity.</p>
            </div>
          </Reveal>
        </div>

        <Reveal delay={250} className="mt-16 text-center">
          <p className="font-display italic text-2xl md:text-3xl text-navy-800 max-w-2xl mx-auto leading-snug">
            &ldquo;Understand the institution first. Recommend the solution next.&rdquo;
          </p>
        </Reveal>
      </div>
    </section>
  );
}
