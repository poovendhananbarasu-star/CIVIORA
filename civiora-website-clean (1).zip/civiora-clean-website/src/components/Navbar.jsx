import { useEffect, useState } from 'react';
import { Menu, X } from 'lucide-react';
import logo from '../assets/civiora-logo-full-lockup-transparent.png';

const LINKS = [
  { href: '#about', label: 'About' },
  { href: '#ecosystem', label: 'Ecosystem' },
  { href: '#pathways', label: 'Pathways' },
  { href: '#how-it-works', label: 'How It Works' },
  { href: '#why-civiora', label: 'Why Civiora' },
  { href: '#network', label: 'Network' },
  { href: '#founder', label: 'Founder' },
  { href: '#contact', label: 'Contact' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled ? 'bg-white/95 backdrop-blur-sm shadow-[0_2px_20px_rgba(11,42,84,0.08)] py-2.5' : 'bg-transparent py-5'
      }`}
    >
      <nav className="max-w-content mx-auto px-6 md:px-10 flex items-center justify-between">
        <a href="#top" className="flex items-center gap-2.5">
          <img src={logo} alt="CIVIORA" className="h-9 md:h-10 w-auto" />
        </a>

        <ul className="hidden lg:flex items-center gap-8 font-body text-sm tracking-wide text-navy-800">
          {LINKS.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                className="relative py-1 hover:text-gold-600 transition-colors duration-300 after:content-[''] after:absolute after:left-0 after:-bottom-0.5 after:h-[1.5px] after:w-0 after:bg-gold-500 after:transition-all after:duration-300 hover:after:w-full"
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        <a
          href="#contact"
          className="hidden lg:inline-flex items-center gap-2 bg-navy-700 hover:bg-navy-800 text-white text-sm font-medium tracking-wide px-5 py-2.5 rounded-full transition-all duration-300 hover:shadow-lg hover:shadow-navy-700/20"
        >
          Book an Appointment
        </a>

        <button
          className="lg:hidden text-navy-800"
          aria-label="Toggle menu"
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X size={26} /> : <Menu size={26} />}
        </button>
      </nav>

      {/* Mobile menu */}
      <div
        className={`lg:hidden overflow-hidden transition-all duration-400 ease-in-out bg-white/98 backdrop-blur-sm ${
          open ? 'max-h-[520px] border-t border-navy-100' : 'max-h-0'
        }`}
      >
        <ul className="flex flex-col px-6 py-4 gap-1 font-body text-navy-800">
          {LINKS.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                onClick={() => setOpen(false)}
                className="block py-2.5 border-b border-navy-50 text-sm tracking-wide"
              >
                {l.label}
              </a>
            </li>
          ))}
          <li>
            <a
              href="#contact"
              onClick={() => setOpen(false)}
              className="mt-3 inline-block w-full text-center bg-navy-700 text-white text-sm font-medium tracking-wide px-5 py-3 rounded-full"
            >
              Book an Appointment
            </a>
          </li>
        </ul>
      </div>
    </header>
  );
}
