import logo from '../assets/civiora-logo-full-lockup-transparent.png';

export default function Footer() {
  return (
    <footer className="bg-navy-950 py-10">
      <div className="max-w-content mx-auto px-6 md:px-10 flex flex-col md:flex-row items-center justify-between gap-6">
        <img src={logo} alt="CIVIORA" className="h-9 w-auto brightness-0 invert opacity-80" />
        <p className="text-navy-400 text-xs md:text-sm text-center md:text-right">
          Connecting Institutions. Building Future-Ready Ecosystems.
        </p>
      </div>
    </footer>
  );
}
