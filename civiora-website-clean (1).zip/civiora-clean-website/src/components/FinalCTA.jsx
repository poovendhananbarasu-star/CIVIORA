import { Mail, Phone, Globe } from 'lucide-react';
import Reveal from './Reveal';

const AUDIENCE = [
  'School leaders and education groups',
  'College and university management',
  'Career-development and placement teams',
  'Academic, mentoring, assessment and technology partners',
];

export default function FinalCTA() {
  return (
    <section id="contact" className="relative bg-navy-900 py-24 md:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_rgba(201,150,42,0.08),_transparent_55%)]" />

      <div className="relative max-w-content mx-auto px-6 md:px-10">
        <Reveal className="text-center max-w-2xl mx-auto">
          
          <h2 className="mt-4 font-display text-3xl md:text-5xl text-white leading-tight">
            Let&rsquo;s Build the Right Institutional Pathway
          </h2>
          <p className="mt-6 text-navy-200 leading-relaxed">
            Whether the requirement is future readiness in schools,
            competitive-career support in higher education or a specialist
            academic partnership, Civiora begins with a focused conversation.
          </p>
        </Reveal>

        <div className="mt-16 grid lg:grid-cols-2 gap-10">
          <Reveal>
            <p className="eyebrow text-gold-400">Who Should Connect</p>
            <ul className="mt-6 space-y-4">
              {AUDIENCE.map((a) => (
                <li key={a} className="flex items-start gap-3 text-navy-100 pb-4 border-b border-white/10 last:border-none">
                  <span className="w-1.5 h-1.5 rounded-full bg-gold-400 mt-2.5 shrink-0" />
                  {a}
                </li>
              ))}
            </ul>

            <div className="mt-10 space-y-4">
              <a href="tel:8150003610" className="flex items-center gap-3 text-navy-100 hover:text-gold-400 transition-colors">
                <Phone size={18} className="text-gold-400" /> 8150003610
              </a>
              <a href="mailto:poovendhananbarasu@gmail.com" className="flex items-center gap-3 text-navy-100 hover:text-gold-400 transition-colors break-all">
                <Mail size={18} className="text-gold-400" /> poovendhananbarasu@gmail.com
              </a>
              <a href="https://www.civiora.in" target="_blank" rel="noreferrer" className="flex items-center gap-3 text-navy-100 hover:text-gold-400 transition-colors">
                <Globe size={18} className="text-gold-400" /> www.civiora.in
              </a>
            </div>
          </Reveal>

          <Reveal delay={150} className="bg-white rounded-3xl p-8 md:p-10">
            <h3 className="font-display text-2xl text-navy-800">Book an Appointment</h3>
            <p className="mt-4 text-navy-500 leading-relaxed">
              Share your institutional priority. Civiora will understand the context, identify the opportunity and recommend the next step.
            </p>
            <a
              href="mailto:poovendhananbarasu@gmail.com?subject=Civiora%20Appointment"
              className="mt-8 inline-flex items-center justify-center bg-navy-800 hover:bg-navy-900 text-white font-medium tracking-wide px-6 py-3.5 rounded-xl transition-all duration-300"
            >
              Book an Appointment
            </a>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
