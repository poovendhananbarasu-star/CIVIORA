import { BookOpen, Landmark, HeartHandshake, Cpu, Check } from 'lucide-react';
import Reveal from './Reveal';

const CATEGORIES = [
  { icon: BookOpen, text: 'Academic organisations and specialist faculty' },
  { icon: Landmark, text: 'Civil Services, State PSC, SSC, Banking and Defence experts' },
  { icon: HeartHandshake, text: 'Mentors, counsellors and student-development professionals' },
  { icon: Cpu, text: 'Assessment, content and education-technology partners' },
];

const FOR_INSTITUTIONS = [
  'One strategic interface',
  'Right-fit expertise',
  'Reduced coordination burden',
  'Implementation visibility',
];

const FOR_PARTNERS = [
  'Qualified institutional opportunities',
  'Clear scope and expectations',
  'Coordinated stakeholder communication',
  'Long-term ecosystem potential',
];

export default function Network() {
  return (
    <section id="network" className="relative bg-white py-24 md:py-32">
      <div className="max-w-content mx-auto px-6 md:px-10">
        <Reveal className="text-center max-w-2xl mx-auto">
          <p className="eyebrow">A Curated Network of Expertise</p>
          <h2 className="section-heading mt-4">
            
          </h2>
          <p className="mt-6 text-navy-600 leading-relaxed">
            Civiora brings together the right combination of expertise for each
            institutional requirement.
          </p>
        </Reveal>

        <div className="mt-16 grid sm:grid-cols-2 gap-5">
          {CATEGORIES.map((c, i) => (
            <Reveal
              key={c.text}
              delay={i * 100}
              className="flex items-start gap-4 bg-mist rounded-2xl p-6 border border-navy-100"
            >
              <div className="w-12 h-12 rounded-xl bg-navy-700 flex items-center justify-center shrink-0">
                <c.icon size={20} className="text-gold-400" />
              </div>
              <p className="text-navy-800 leading-snug pt-2">{c.text}</p>
            </Reveal>
          ))}
        </div>

        <Reveal delay={150} className="mt-16 max-w-2xl mx-auto text-center">
          <p className="text-navy-600 leading-relaxed italic">
            &ldquo;We collaborate with credible providers who can demonstrate
            expertise, delivery capacity, professional references and
            commitment to agreed quality standards.&rdquo;
          </p>
        </Reveal>

        <div className="mt-16 grid md:grid-cols-2 gap-8">
          <Reveal className="rounded-2xl border border-navy-100 p-8">
            <h3 className="font-display text-xl text-navy-800">For Institutions</h3>
            <ul className="mt-5 space-y-3">
              {FOR_INSTITUTIONS.map((p) => (
                <li key={p} className="flex items-center gap-2.5 text-navy-700 text-sm">
                  <Check size={16} className="text-gold-500 shrink-0" />
                  {p}
                </li>
              ))}
            </ul>
          </Reveal>
          <Reveal delay={120} className="rounded-2xl border border-navy-100 p-8">
            <h3 className="font-display text-xl text-navy-800">For Service Partners</h3>
            <ul className="mt-5 space-y-3">
              {FOR_PARTNERS.map((p) => (
                <li key={p} className="flex items-center gap-2.5 text-navy-700 text-sm">
                  <Check size={16} className="text-gold-500 shrink-0" />
                  {p}
                </li>
              ))}
            </ul>
          </Reveal>
        </div>

        <Reveal delay={200} className="mt-16 text-center">
          <p className="eyebrow">Our Standard</p>
          <p className="mt-4 font-display italic text-2xl md:text-3xl text-navy-800 max-w-2xl mx-auto leading-snug">
            &ldquo;The right expertise for the right requirement—within a
            governed institutional engagement.&rdquo;
          </p>
        </Reveal>
      </div>
    </section>
  );
}
