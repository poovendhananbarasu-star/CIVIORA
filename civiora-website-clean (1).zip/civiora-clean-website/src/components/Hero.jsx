import { ArrowRight, ChevronDown } from 'lucide-react';

export default function Hero() {
  return (
    <section
      id="top"
      className="relative min-h-screen flex items-center bg-navy-800 overflow-hidden"
    >
      {/* Abstract institutional/pathway visual language — no stock photography */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_rgba(201,150,42,0.10),_transparent_55%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,_rgba(255,255,255,0.05),_transparent_50%)]" />

        <svg
          className="absolute inset-0 w-full h-full opacity-[0.18]"
          viewBox="0 0 1200 800"
          preserveAspectRatio="xMidYMid slice"
          fill="none"
        >
          {[0, 1, 2, 3, 4].map((i) => (
            <path
              key={i}
              d={`M -100 ${140 + i * 110} C 300 ${60 + i * 110}, 700 ${240 + i * 110}, 1300 ${100 + i * 110}`}
              stroke={i % 2 === 0 ? '#C9962A' : '#FFFFFF'}
              strokeWidth="1"
              className="animate-[fadeUp_2s_ease-out_forwards]"
              style={{ animationDelay: `${i * 150}ms` }}
            />
          ))}
        </svg>

        {/* Faint brand mark, oversized, bottom-right */}
        <div className="absolute -right-24 -bottom-24 w-[520px] h-[520px] rounded-full border border-white/10" />
        <div className="absolute -right-10 -bottom-10 w-[340px] h-[340px] rounded-full border border-gold-400/20" />
      </div>

      <div className="relative z-10 max-w-content mx-auto px-6 md:px-10 pt-32 pb-24 w-full">
                <h1
          className="mt-6 font-display text-white text-[2.5rem] leading-[1.15] sm:text-6xl md:text-7xl md:leading-[1.1] max-w-4xl opacity-0 animate-fadeUp"
          style={{ animationDelay: '250ms' }}
        >
          Connecting Institutions.
          <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-gold-300 to-gold-500">
            Building Future-Ready
          </span>{' '}
          Ecosystems.
        </h1>

        <div className="mt-8 flex items-center gap-4 opacity-0 animate-fadeUp" style={{ animationDelay: '400ms' }}>
          <span className="gold-rule" />
          <h2 className="font-body text-lg md:text-xl text-navy-100 tracking-wide">
            From Institutional Need to the Right Ecosystem
          </h2>
        </div>

        <p
          className="mt-5 text-navy-200 text-sm md:text-base tracking-[0.15em] uppercase opacity-0 animate-fadeUp"
          style={{ animationDelay: '500ms' }}
        >
          Future Readiness &nbsp;•&nbsp; Competitive Careers &nbsp;•&nbsp; Institutional Partnerships
        </p>

        <div className="mt-12 opacity-0 animate-fadeUp" style={{ animationDelay: '650ms' }}>
          <a
            href="#contact"
            className="group inline-flex items-center gap-3 bg-gold-500 hover:bg-gold-400 text-navy-900 font-semibold tracking-wide px-7 py-4 rounded-full transition-all duration-300 hover:shadow-xl hover:shadow-gold-500/20"
          >
            Let&rsquo;s Build the Right Institutional Pathway
            <ArrowRight size={18} className="transition-transform duration-300 group-hover:translate-x-1" />
          </a>
        </div>
      </div>

      <a
        href="#about"
        aria-label="Scroll to content"
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 text-white/60 hover:text-gold-400 transition-colors animate-bounce"
      >
        <ChevronDown size={28} />
      </a>
    </section>
  );
}
