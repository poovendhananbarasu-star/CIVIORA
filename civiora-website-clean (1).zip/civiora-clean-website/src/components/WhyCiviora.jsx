import { Target, Users, Compass, SlidersHorizontal, BadgeCheck, LineChart } from 'lucide-react';
import Reveal from './Reveal';

const REASONS = [
  {
    icon: Target,
    title: 'Need-led',
    quote: 'The solution begins with the institution—not a pre-built catalogue.',
  },
  {
    icon: Users,
    title: 'Provider-neutral',
    quote: 'Specialists are selected according to requirement and fit.',
  },
  {
    icon: Compass,
    title: 'One accountable interface',
    quote: 'Civiora coordinates institutions and service providers.',
  },
  {
    icon: SlidersHorizontal,
    title: 'Flexible implementation',
    quote: 'Scope can adapt to campus, cohort, schedule and scale.',
  },
  {
    icon: BadgeCheck,
    title: 'Quality governed',
    quote: 'Responsibilities, standards and communication are clearly managed.',
  },
  {
    icon: LineChart,
    title: 'Measurable',
    quote: 'Participation, feedback and agreed progress indicators remain visible.',
  },
];

export default function WhyCiviora() {
  return (
    <section id="why-civiora" className="relative bg-mist py-24 md:py-32">
      <div className="max-w-content mx-auto px-6 md:px-10">
        <Reveal className="text-center max-w-2xl mx-auto">
          <p className="eyebrow">Why Institutions Choose Civiora</p>
          <h2 className="section-heading mt-4"></h2>
        </Reveal>

        <div className="mt-16 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {REASONS.map((r, i) => (
            <Reveal
              key={r.title}
              delay={i * 100}
              className="group bg-white rounded-2xl p-8 border border-navy-100 hover:border-gold-400 hover:-translate-y-1 transition-all duration-400"
            >
              <r.icon size={28} className="text-gold-500" />
              <h3 className="mt-5 font-display text-xl text-navy-800">{r.title}</h3>
              <p className="mt-3 text-navy-500 text-sm leading-relaxed italic">&ldquo;{r.quote}&rdquo;</p>
            </Reveal>
          ))}
        </div>

        <Reveal delay={200} className="mt-20 bg-navy-800 rounded-3xl px-8 py-14 md:py-16 text-center">
          <p className="eyebrow text-gold-400">The Civiora Promise</p>
          <p className="mt-5 font-display text-3xl md:text-4xl text-white">Clarity before commitment.</p>
          <p className="mt-6 text-navy-200 max-w-2xl mx-auto leading-relaxed">
            We do not begin by selling a programme. We begin by understanding
            the need, defining the outcome and designing the most suitable
            institutional response.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
