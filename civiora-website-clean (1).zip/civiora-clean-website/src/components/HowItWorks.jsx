import { Search, PenSquare, Link2, ShieldCheck, BarChart3 } from 'lucide-react';
import Reveal from './Reveal';

const STEPS = [
  { icon: Search, label: 'Discover', desc: 'Requirement mapping and solution architecture.' },
  { icon: PenSquare, label: 'Design', desc: 'Design the right institutional response.' },
  { icon: Link2, label: 'Connect', desc: 'Partner evaluation and alignment.' },
  { icon: ShieldCheck, label: 'Govern', desc: 'Stakeholder coordination, delivery standards and quality oversight.' },
  { icon: BarChart3, label: 'Measure', desc: 'Student experience, feedback and reporting.' },
];

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="relative bg-white py-24 md:py-32">
      <div className="max-w-content mx-auto px-6 md:px-10">
        <Reveal className="text-center max-w-2xl mx-auto">
          <p className="eyebrow">How Civiora Works</p>
          <h2 className="section-heading mt-4">
            Discover &rarr; Design &rarr; Connect &rarr; Govern &rarr; Measure
          </h2>
        </Reveal>

        <div className="mt-20 grid md:grid-cols-5 gap-10 md:gap-6 relative">
          <div className="hidden md:block absolute top-8 left-[10%] right-[10%] h-px bg-gradient-to-r from-transparent via-gold-500/50 to-transparent" />
          {STEPS.map((s, i) => (
            <Reveal key={s.label} delay={i * 120} className="relative flex flex-col items-center text-center">
              <div className="relative z-10 w-16 h-16 rounded-full bg-mist border border-gold-400/50 flex items-center justify-center">
                <s.icon size={26} className="text-navy-700" />
              </div>
              <h3 className="mt-5 font-display text-xl text-navy-800 tracking-wide">{s.label}</h3>
              <p className="mt-2 text-navy-500 text-sm leading-relaxed max-w-[200px]">{s.desc}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
