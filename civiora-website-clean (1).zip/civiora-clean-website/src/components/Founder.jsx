import Reveal from './Reveal';
import mark from '../assets/civiora-mark-icon.png';

const STATS = [
  { value: '9+', label: 'Years in academic experience' },
  { value: '4,000+', label: 'Students mentored' },
  { value: '60,000+', label: 'Learners reached' },
  { value: '70+', label: 'Institutions of exposure' },
];

export default function Founder() {
  return (
    <section id="founder" className="relative bg-navy-900 py-24 md:py-32 overflow-hidden">
      <img src={mark} alt="" className="absolute -left-20 -top-20 w-72 opacity-[0.05] pointer-events-none" />

      <div className="relative max-w-content mx-auto px-6 md:px-10">
        <Reveal className="text-center max-w-2xl mx-auto">
          <p className="eyebrow">Meet the Founder &amp; CEO</p>
          <h2 className="mt-4 font-display text-3xl md:text-5xl text-white">A. Poovendhan Anbarasu</h2>
          <p className="mt-2 text-gold-400 tracking-wide uppercase text-sm">Founder &amp; CEO, Civiora</p>
        </Reveal>

        <Reveal delay={150} className="mt-12 max-w-3xl mx-auto text-center">
          <p className="text-navy-100 text-lg leading-relaxed">
            Poovendhan&rsquo;s journey brings together competitive-examination
            experience, classroom teaching, student mentoring, academic
            leadership and institutional partnerships. His experience includes
            serving as Vice President&nbsp;&ndash;&nbsp;Knowledge Labs, with
            responsibilities spanning programme architecture, institutional
            engagement, academic delivery, mentoring, counselling and
            partnership development.
          </p>
        </Reveal>

        <Reveal delay={250} className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6">
          {STATS.map((s) => (
            <div key={s.label} className="text-center border-t border-gold-500/30 pt-6">
              <p className="font-display text-3xl md:text-4xl text-gold-400">{s.value}</p>
              <p className="mt-2 text-navy-200 text-xs md:text-sm leading-snug">{s.label}</p>
            </div>
          ))}
        </Reveal>

        <Reveal delay={350} className="mt-14 text-center">
          <p className="eyebrow">Core Expertise</p>
          <p className="mt-3 text-white font-display text-xl md:text-2xl">
            Civil Services Strategy &nbsp;&middot;&nbsp; Indian Polity &nbsp;&middot;&nbsp; Indian &amp; World History
          </p>
        </Reveal>
      </div>
    </section>
  );
}
