import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Ecosystem from './components/Ecosystem';
import Pathways from './components/Pathways';
import HowItWorks from './components/HowItWorks';
import WhyCiviora from './components/WhyCiviora';
import Network from './components/Network';
import Founder from './components/Founder';
import ExamPerspective from './components/ExamPerspective';
import FinalCTA from './components/FinalCTA';
import Footer from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <main>
        <Hero />
        <About />
        <Ecosystem />
        <Pathways />
        <HowItWorks />
        <WhyCiviora />
        <Network />
        <Founder />
        <ExamPerspective />
        <FinalCTA />
      </main>
      <Footer />
    </div>
  );
}
